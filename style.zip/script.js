const products = [
  { name: "Solar Panel" },
  { name: "Battery Pack" },
  { name: "Inverter" },
];

const grid = document.getElementById("productGrid");

products.forEach(product => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `<h3>${product.name}</h3>`;
  grid.appendChild(card);
});
